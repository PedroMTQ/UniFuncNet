'''
download genome
we chose bio17 since it was less fragmented
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3497503/
https://www.ncbi.nlm.nih.gov/nuccore/AMPG00000000


annotate with mantis
build model
check connectivity model
extract ids from model
extract ids from mantis annotation
run drax on ids not in model -> this will accelerate scraping but not restrict model evaluation





DRAX command:
python DRAX/ pr protein_search -t drax.tsv -o drax_manuscript -db kegg -rm
python DRAX/ pr protein_search -t drax.tsv -o drax_manuscript -rm


'''
import networkx as nx
import matplotlib.pyplot as plt
import scipy as sp

model_file='model_gapseq/microthrix.xml'
mantis_annotations='microthrix_kegg_ncbi/consensus_annotation.tsv'
tsv_file='drax.tsv'
drax_output='drax_output_kegg_ncbi'





def create_network_model(dict_reactions):
    print('Model network')

    G = nx.DiGraph()
    for reaction_id in dict_reactions:
        for r in dict_reactions[reaction_id]['reactants']:
            G.add_edge(r, reaction_id)
        for p in dict_reactions[reaction_id]['products']:
            G.add_edge(reaction_id,p)

    return G

def create_network_drax(reactions_dict,compounds_match):
    print('DRAX network')
    G = nx.DiGraph()

    for reaction_id in reactions_dict:
        drax_reaction_id=f'R_{reaction_id}'
        reaction_cpds=reactions_dict[reaction_id]['reaction_compounds']
        if ' => ' in reaction_cpds: reaction_cpds=reaction_cpds.replace(' => ',' <=> ')
        if ' <= ' in reaction_cpds: reaction_cpds=reaction_cpds.replace(' <= ',' <=> ')
        drax_reactants,drax_products=reaction_cpds.split('<=>')
        drax_reactants,drax_products=[j.strip() for j in drax_reactants.split('+')],[j.strip() for j in drax_products.split('+')]
        for reactant in drax_reactants:
            if reactant in compounds_match:
                reactant=compounds_match[reactant]
            else: reactant={reactant}
            for product in drax_products:
                if product in compounds_match:
                    product = compounds_match[product]
                else:
                    product = {product}


                for r in reactant:
                    G.add_edge(r,drax_reaction_id)
                for p in product:
                    G.add_edge(drax_reaction_id,p)

    return G

def create_network_expanded(reactions_model,reactions_drax,compounds_match):
    print('Expanded network')
    G = nx.DiGraph()
    for reaction_id in reactions_model:
        for r in reactions_model[reaction_id]['reactants']:
            G.add_edge(r, reaction_id)
        for p in reactions_model[reaction_id]['products']:
            G.add_edge(reaction_id,p)
    for reaction_id in reactions_drax:
        drax_reaction_id=f'R_{reaction_id}'
        reaction_cpds=reactions_drax[reaction_id]['reaction_compounds']
        if ' => ' in reaction_cpds: reaction_cpds=reaction_cpds.replace(' => ',' <=> ')
        if ' <= ' in reaction_cpds: reaction_cpds=reaction_cpds.replace(' <= ',' <=> ')
        drax_reactants,drax_products=reaction_cpds.split('<=>')
        drax_reactants,drax_products=[j.strip() for j in drax_reactants.split('+')],[j.strip() for j in drax_products.split('+')]

        for reactant in drax_reactants:
            if reactant in compounds_match:
                reactant=compounds_match[reactant]
            else: reactant={reactant}
            for product in drax_products:
                if product in compounds_match:
                    product = compounds_match[product]
                else:
                    product = {product}
                for r in reactant:
                    G.add_edge(r,drax_reaction_id)
                for p in product:
                    G.add_edge(drax_reaction_id,p)
    return G

def check_dead_end_metabolites(graph):
    products=set()
    reactants=set()
    for n1,n2 in graph.edges():
        #reaction -> product
        if n1.startswith('R_') and not n2.endswith('_e0'):
            products.add(n2)
    for n1,n2 in graph.edges():
        #reactant -> reaction
        if n2.startswith('R_') and not n1.endswith('_e0'):
            reactants.add(n1)
    transported=set()
    for n1,n2 in graph.edges():
        if n1.endswith('_e0'):
            transported.add(n1)
        if n2.endswith('_e0'):
            transported.add(n2)

    res=set()

    for product in products:
        if not n1.endswith('_e0'):
            if product not in reactants:
                res.add(product)
    for reactant in reactants:
        if not n1.endswith('_e0'):
            if reactant not in products:
                res.add(reactant)
    all_metabolites=[n for n in graph.nodes() if not n.startswith('R_') and not n.endswith('_e0')]
    print('all valid metabolites',len(all_metabolites))
    print('Dead end metabolites',len(res))
    print('Transported metabolites',len(transported))
    print('Percentage dead end metabolites',100*len(res)/len(all_metabolites))
    return res


def compare_dead_end_metabolites(graph1, graph2):
    dead_end1 = check_dead_end_metabolites(graph1)
    dead_end2 = check_dead_end_metabolites(graph2)
    new_dead_ends = set()
    connected=set()
    #original
    for dead in dead_end1:
        #expanded
        if dead not in dead_end2:
            #connected
            connected.add(dead)

    for dead in dead_end2:
        if dead not in dead_end1:
            new_dead_ends.add(dead)

    print('Original dead end metabolites', len(dead_end1))
    print('Expanded dead end metabolites', len(dead_end2))
    print('New dead end metabolites', len(new_dead_ends))
    print('Newly connected metabolites', len(connected))
    print(new_dead_ends)
    print(connected)


def evaluate_network(graph,evaluation_function):
    check_dead_end_metabolites(graph)

    subnetworks = sorted(evaluation_function(graph), key=len, reverse=True)
    periplasmic=0
    extracellular=0
    cytosol=0
    size_subnetworks_nodes={}
    size_subnetworks_reactions={}
    for node in graph.nodes():
        if node.endswith('_p0'):
            periplasmic+=1
        elif node.endswith('_e0'):
            extracellular+=1
        elif node.endswith('_c0'):
            cytosol+=1
    for subnet in subnetworks:
        nodes=[n for n in graph.subgraph(subnet).nodes() if not n.startswith('R_')]
        reactions=[n for n in graph.subgraph(subnet).nodes() if n.startswith('R_')]
        size_subnet_nodes=len(nodes)
        if size_subnet_nodes not in size_subnetworks_nodes: size_subnetworks_nodes[size_subnet_nodes]=0
        size_subnetworks_nodes[size_subnet_nodes]+=1
        size_subnet_reactions=len(reactions)
        if size_subnet_reactions not in size_subnetworks_reactions: size_subnetworks_reactions[size_subnet_reactions]=0
        size_subnetworks_reactions[size_subnet_reactions]+=1


    n_reactions = len([n for n in graph.nodes() if n.startswith('R_')])
    percentage_reactions_largest_component=100*max(size_subnetworks_reactions.keys())/n_reactions
    print('% reactions largest component',percentage_reactions_largest_component)

def read_model(model_file):
    reactions={}
    with open(model_file) as file:
        line=file.readline()
        while line:
            line=line.strip('\n')
            if '<reaction metaid' in line:
                reaction_id=line.split('metaid="')[1].split('id=')[0].strip().strip('"')
                reactions[reaction_id]={'reactants':[],'products':[]}
            elif '<listOfReactants' in line:
                while '</listOfReactants' not in line:
                    line=file.readline()
                    if '<speciesReference species=' in line:
                        reactant=line.split('<speciesReference species="')[1].split('stoichiometry=')[0].strip().strip('"')
                        reactions[reaction_id]['reactants'].append(reactant)
            elif '<listOfProducts' in line:
                while '</listOfProducts' not in line:
                    line=file.readline()
                    if '<speciesReference species=' in line:
                        reactant=line.split('<speciesReference species="')[1].split('stoichiometry=')[0].strip().strip('"')
                        reactions[reaction_id]['products'].append(reactant)
            line=file.readline()

    return reactions


def extract_model_ids_proteins_and_reactions(model_file):
    res= {}
    record=False
    with open(model_file) as file:
        line=file.readline()
        while line:
            line=line.strip('\n')
            if '<reaction metaid' in line:
                reaction_id=line.split('metaid="')[1].split('id=')[0].strip().strip('"')
                res[reaction_id]={}
                record=True
            elif 'rdf:resource' in line and record:
                identifier=line.split('/')[-2]
                if 'ec-code:' in identifier:
                    if 'enzyme_ec' not in res[reaction_id]: res[reaction_id]['enzyme_ec']=set()
                    identifier=identifier.split('ec-code:')[1].strip('"')
                    res[reaction_id]['enzyme_ec'].add(identifier)
                elif 'kegg.reaction:' in identifier:
                    if 'kegg_reaction' not in res[reaction_id]: res[reaction_id]['kegg_reaction']=set()
                    identifier=identifier.split('kegg.reaction:')[1].strip('"')
                    res[reaction_id]['kegg_reaction'].add(identifier)
                elif 'bigg.reaction:' in identifier: pass
                elif 'seed.reaction:' in identifier: pass
                elif 'metanetx.reaction:' in identifier: pass
                elif 'SBO:' in identifier: pass
                elif 'biocyc:' in identifier:
                    if 'biocyc' not in res[reaction_id]: res[reaction_id]['biocyc']=set()
                    identifier=identifier.split('biocyc:META:')[1].strip('"')
                    res[reaction_id]['biocyc'].add(identifier)

                else:
                    print(identifier)
            elif '</reaction>' in line: record=False

            line=file.readline()
    all_ids={}
    for reaction_id in res:
        for id_type in res[reaction_id]:
            if id_type not in all_ids: all_ids[id_type]=set()
            all_ids[id_type].update(res[reaction_id][id_type])
    print('Model reactions:',len(res))
    print('Model reactions with KEGG IDs:',len([i for i in res if 'kegg_reaction' in res[i]]))
    print('Model reactions with EC IDs:',len([i for i in res if 'enzyme_ec' in res[i]]))
    print('Model annotations:')
    for id_type in all_ids:
        print(id_type,len(all_ids[id_type]))
    return all_ids

def extract_model_ids_compounds(model_file):
    res= {}
    record=False
    with open(model_file) as file:
        line=file.readline()
        while line:
            line=line.strip('\n')
            if '<species metaid' in line:
                compound_id=line.split('metaid="')[1].split('id=')[0].strip().strip('"')
                res[compound_id]={}
                record=True
            elif 'rdf:resource' in line and record:
                identifier=line.split('/')[-2]

                if 'kegg.compound:' in identifier:
                    if 'kegg' not in res[compound_id]: res[compound_id]['kegg']=set()
                    identifier=identifier.split(':')[1].strip('"')
                    res[compound_id]['kegg'].add(identifier)
                elif 'CHEBI:' in identifier:
                    if 'chebi' not in res[compound_id]: res[compound_id]['chebi']=set()
                    identifier=identifier.split(':')[1].strip('"')
                    res[compound_id]['chebi'].add(identifier)
                elif 'SBO:' in identifier: pass
                elif 'inchikey:' in identifier:
                    if 'inchikey' not in res[compound_id]: res[compound_id]['inchi_key']=set()
                    identifier=identifier.split(':')[1].strip('"')
                    res[compound_id]['inchi_key'].add(identifier)

                elif 'hmdb:' in identifier:
                    if 'hmdb' not in res[compound_id]: res[compound_id]['hmdb']=set()
                    identifier=identifier.split(':')[1].strip('"')
                    res[compound_id]['hmdb'].add(identifier)

                elif 'reactome:' in identifier: pass
                elif 'bigg.metabolite:' in identifier: pass
                elif 'biocyc:' in identifier:
                    if 'biocyc' not in res[compound_id]: res[compound_id]['biocyc']=set()
                    identifier=identifier.split(':')[1].strip('"')
                    res[compound_id]['biocyc'].add(identifier)

                else:
                    #'metanetx.chemical/' and 'seed.compound/'
                    pass
            elif '</species>' in line: record=False

            line=file.readline()
    compound_dict={}
    print('All compounds in model',len(res))
    for i in res:
        if res[i]:
            compound_dict[i]=res[i]
    print('All matcheable compounds',len(compound_dict))
    return compound_dict

def extract_mantis_ids(mantis_annotations):
    res={}
    with open(mantis_annotations) as file:
        line=file.readline()
        while line:
            line=line.strip('\n')
            line=line.split('\t')
            protein_annotations=line[6:]
            for annot in protein_annotations:
                if annot.startswith('enzyme_ec') or \
                        annot.startswith('kegg_reaction') or\
                        annot.startswith('kegg_ko'):
                    id_type,annotation=annot.split(':')
                    if id_type not in res: res[id_type]=set()
                    res[id_type].add(annotation)
            line=file.readline()
    print('Mantis annotations:')
    for id_type in res:
        print(id_type,len(res[id_type]))
    return res

def ids_to_run_drax(mantis_annotations,model_file):
    mantis_ids=extract_mantis_ids(mantis_annotations)
    model_ids=extract_model_ids_proteins_and_reactions(model_file)
    res={}
    for id_type in mantis_ids:
        if id_type not in res: res[id_type]=set()
        if id_type in model_ids:
            for annot in mantis_ids[id_type]:
                if annot not in model_ids[id_type]:
                    res[id_type].add(annot)
        else:
            res[id_type]=mantis_ids[id_type]
    print('IDs unique to Mantis:')
    for id_type in res:
        print(id_type,len(res[id_type]))
    return res

def compile_input_drax(mantis_annotations,model_file,tsv_file):
    '''
    we now get all ids from the model and mantis
    we check which new annotations we get from mantis, and export these new annotations to a tsv file
    this tsv file will be given to drax to search for more information

    '''
    ids_to_run=ids_to_run_drax(mantis_annotations,model_file)
    with open(tsv_file,'w+') as file:
        for id_type in ids_to_run:
            for annot in ids_to_run[id_type]:
                file.write(f'{id_type}\t{annot}\n')


def read_drax_tsv(drax_tsv):
    res={}
    with open(drax_tsv) as file:
        line=file.readline()
        while line:
            line=line.strip('\n').split('\t')
            internal_id=line.pop(0).split(':')[1]
            for i in line:
                id_type=i.split(':')[0]
                annot=i.replace(id_type+':','')
                if internal_id not in res: res[internal_id]={}
                if id_type not in res[internal_id] and id_type!='reaction_compounds': res[internal_id][id_type]=set()
                if id_type=='reaction_compounds':res[internal_id][id_type]=annot
                else:
                    res[internal_id][id_type].add(annot)
            line=file.readline()
    return res

def remove_proteins_without_reaction(proteins_dict):
    res={}
    for i in proteins_dict:
        if 'reactions_connected' in proteins_dict[i]:
            res[i]=proteins_dict[i]
    return res

def remove_proteins_drax_in_model(model_ids,proteins_dict):
    '''
    since mantis annotations sometimes only had KOs, we now check whether we already had the respective ECs in the model

    '''
    res={}
    for i in proteins_dict:
        if 'enzyme_ec' in proteins_dict[i]:
            if not proteins_dict[i]['enzyme_ec'].intersection(model_ids['enzyme_ec']):
                res[i]=proteins_dict[i]
    return res

def remove_reactions_without_proteins_in_drax(proteins_dict,reactions_dict):
    '''
    some proteins were found by drax but were already in the model, so now we have to remove those and their respective reactions

    '''
    res={}
    for i in proteins_dict:
        for r  in proteins_dict[i]['reactions_connected']:
            res[r]=reactions_dict[r]
    return res


def remove_reactions_drax_in_model_ids(model_ids,reactions_dict):
    '''
    some of the reactions from drax were already in the model, so now we remove them

    '''
    res={}
    for i in reactions_dict:
        passed=False
        if 'kegg' in reactions_dict[i]:
            if reactions_dict[i]['kegg'].intersection(model_ids['kegg_reaction']):
                passed=True
        if 'biocyc' in reactions_dict[i]:
            if reactions_dict[i]['biocyc'].intersection(model_ids['biocyc']):
                passed=True
        if not passed:
            if 'kegg'in reactions_dict[i] or 'biocyc'in reactions_dict[i]:
                res[i] = reactions_dict[i]

    return res

def match_compounds_drax_model(model_file,compounds_dict):
    model_compounds=extract_model_ids_compounds(model_file)
    res={}
    counter=set()
    for i in compounds_dict:
        for j in model_compounds:
            if 'kegg' in compounds_dict[i] and 'kegg' in model_compounds[j]:
                if compounds_dict[i]['kegg'].intersection(model_compounds[j]['kegg']):
                    if i not in res: res[i]=set()
                    res[i].add(j)
                    counter.add(j)
            if 'chebi' in compounds_dict[i] and 'chebi' in model_compounds[j]:
                if compounds_dict[i]['chebi'].intersection(model_compounds[j]['chebi']):
                    if i not in res: res[i]=set()
                    res[i].add(j)
                    counter.add(j)
            if 'inchi_key' in compounds_dict[i] and 'inchi_key' in model_compounds[j]:
                if compounds_dict[i]['inchi_key'].intersection(model_compounds[j]['inchi_key']):
                    if i not in res: res[i]=set()
                    res[i].add(j)
                    counter.add(j)
            if 'biocyc' in compounds_dict[i] and 'biocyc' in model_compounds[j]:
                if compounds_dict[i]['biocyc'].intersection(model_compounds[j]['biocyc']):
                    if i not in res: res[i]=set()
                    res[i].add(j)
                    counter.add(j)
            if 'hmdb' in compounds_dict[i] and 'hmdb' in model_compounds[j]:
                if compounds_dict[i]['hmdb'].intersection(model_compounds[j]['hmdb']):
                    if i not in res: res[i]=set()
                    res[i].add(j)
                    counter.add(j)
    return res,counter

def check_match_reactions(model_compounds,drax_compounds):
    res=0
    for r1 in model_compounds:
        r1_set={r1}
        for r2 in drax_compounds:
            if r1_set.intersection(r2):
                res += 1
    return res

def remove_reactions_drax_in_model_cpds(model_file,reactions_dict,compounds_match):
    model_data=read_model(model_file)
    res={}
    translated = set()
    untranslated = set()

    for r_drax in reactions_dict:
        reaction_cpds=reactions_dict[r_drax]['reaction_compounds']
        if ' => ' in reaction_cpds: reaction_cpds=reaction_cpds.replace(' => ',' <=> ')
        if ' <= ' in reaction_cpds: reaction_cpds=reaction_cpds.replace(' <= ',' <=> ')
        drax_reactants,drax_products=reaction_cpds.split('<=>')
        drax_reactants,drax_products=[j.strip() for j in drax_reactants.split('+')],[j.strip() for j in drax_products.split('+')]
        translated_reactants,translated_products=[],[]
        for cpd in drax_reactants:
            if cpd in compounds_match:
                translated_reactants.append(compounds_match[cpd])
                translated.add(cpd)
            else:
                untranslated.add(cpd)
        for cpd in drax_products:
            if cpd in compounds_match:
                translated_products.append(compounds_match[cpd])
                translated.add(cpd)
            else:
                untranslated.add(cpd)
        #print(untranslated,len(drax_reactants),len(translated_reactants),len(drax_products),len(translated_products))
        if len(translated_reactants)==len(drax_reactants) and len(translated_products)==len(drax_products):
            for r_model in model_data:
                model_reactants,model_products= model_data[r_model]['reactants'],model_data[r_model]['products']
                match_reactants=check_match_reactions(model_reactants,translated_reactants)
                match_products=check_match_reactions(model_products,translated_products)
                if len(model_reactants) and len(model_products):
                    if match_reactants==len(model_reactants) and match_products==len(model_products):
                        res[r_drax]=r_model

                    match_reactants=check_match_reactions(model_reactants,translated_products)
                    match_products=check_match_reactions(model_products,translated_reactants)
                    if match_reactants==len(model_reactants) and match_products==len(model_products):
                        res[r_drax]=r_model
    print('Matched compounds',len(translated))
    print('Unmatched compounds',len(untranslated))
    unmatched={}
    for i in reactions_dict:
        if i not in res:
            unmatched[i]=reactions_dict[i]
    return unmatched

def read_output_drax(model_file,drax_output):
    '''
    now we have information from drax where we used the extra mantis annotations as seed
    first we need to match the identifiers from drax/Proteins to the model ids, and exclude those, since it might be that we didn't find a match before due to the ids being different
    '''
    model_reactions=read_model(model_file)
    model_ids=extract_model_ids_proteins_and_reactions(model_file)
    compounds_drax=read_drax_tsv(drax_output+'/Compounds.tsv')
    compounds_match,counter=match_compounds_drax_model(model_file,compounds_drax)
    print('All compounds matched',len(counter))
    proteins_drax=read_drax_tsv(drax_output+'/Proteins.tsv')
    print('All proteins found by drax',len(proteins_drax))
    #now we remove proteins without a reaction
    proteins_drax=remove_proteins_without_reaction(proteins_drax)
    print('All proteins with a reaction',len(proteins_drax))
    proteins_drax=remove_proteins_drax_in_model(model_ids,proteins_drax)
    print('All proteins absent in the model',len(proteins_drax))

    reactions_drax=read_drax_tsv(drax_output+'/Reactions.tsv')
    print('All reactions found by drax',len(reactions_drax))
    reactions_drax=remove_reactions_without_proteins_in_drax(proteins_drax,reactions_drax)
    print('All reactions with proteins in drax',len(reactions_drax))
    reactions_drax=remove_reactions_drax_in_model_ids(model_ids,reactions_drax)
    print('All reactions absent in the model (IDs)',len(reactions_drax))
    reactions_drax=remove_reactions_drax_in_model_cpds(model_file,reactions_drax,compounds_match)
    print('All reactions absent in the model (compound matching)',len(reactions_drax))
    drax_network=create_network_drax(reactions_drax,compounds_match)
    evaluate_network(drax_network,nx.weakly_connected_components)

    model_network=create_network_model(model_reactions)
    evaluate_network(model_network,nx.weakly_connected_components)

    expanded_network=create_network_expanded(model_reactions,reactions_drax,compounds_match)
    evaluate_network(expanded_network,nx.weakly_connected_components)
    compare_dead_end_metabolites(model_network,expanded_network)




#compile_input_drax(mantis_annotations,model_file,tsv_file)
read_output_drax(model_file,drax_output)
